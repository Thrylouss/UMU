import styles from "../styles.module.css";
import { useState } from "react";

export default function ListeningQuestions({ questions }) {
    const [selectedAnswers, setSelectedAnswers] = useState({});

    const handleAnswerChange = (questionIndex, answer) => {
        setSelectedAnswers((prev) => ({
            ...prev,
            [questionIndex]: answer,
        }));
    };

    return (
        <div className={styles.questionsContainer}>
            <h3 className={styles.sectionTitle}>Answer the Questions</h3>
            {questions.rows.map((question, index) => (
                <div key={index} className={styles.questionBlock}>
                    <p className={styles.questionText}>{question.question}</p>
                    <div className={styles.options}>
                        {[1, 2, 3, 4].map((num) => (
                            <label key={num} className={styles.option}>
                                <input
                                    type="radio"
                                    name={`question-${index}`}
                                    value={question[`option__${num}`]}
                                    onChange={() =>
                                        handleAnswerChange(index, question[`option__${num}`])
                                    }
                                />
                                {question[`option__${num}`]}
                            </label>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
}
