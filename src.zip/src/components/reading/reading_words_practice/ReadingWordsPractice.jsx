import styles from "../styles.module.css";


export default function ReadingWordsPractice({ reading }) {
    return (
        <>
            <h3 className={styles.sectionTitle}>Words Practice</h3>
            <div className={styles.gridContainer}>
                {reading.reading_words_practice.rows.map((practice, index) => (
                    <section key={index} className={styles.practiceItem}>
                        <p className={styles.question}>{practice.question}</p>
                        {["option__1", "option__2", "option__3"].map((optionKey) => (
                            <label key={optionKey} className={styles.labelQuestion}>
                                <input
                                    type="radio"
                                    name={`words_practice_${index}`}
                                    value={practice[optionKey]}
                                />
                                <span>{practice[optionKey]}</span>
                            </label>
                        ))}
                    </section>
                ))}
            </div>
        </>
    )
}