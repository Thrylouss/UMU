import React, { useState } from 'react';
import styles from './styles.module.css'; // Убедитесь, что путь к CSS-файлу указан правильно

export default function FillInTheBlanks({ data }) {
    const [answers, setAnswers] = useState({});

    const handleInputChange = (index, value) => {
        setAnswers((prev) => ({
            ...prev,
            [index]: value,
        }));
    };

    // Объединяем все вопросы в одну строку
    const combinedText = data.rows.map(row => row.question).join(' ');

    // Разбиваем текст на части, заменяя пропуски на поля ввода
    const parts = combinedText.split(/(\(\d+\)\s*_{3,})/);

    return (
        <div className={styles.container}>
            <p>
                {parts.map((part, index) =>
                    part.match(/^\(\d+\)\s*_{3,}$/) ? (
                        <input
                            key={index}
                            type="text"
                            value={answers[index] || ''}
                            onChange={(e) => handleInputChange(index, e.target.value)}
                            className={styles.input}
                            placeholder=""
                        />
                    ) : (
                        part
                    )
                )}
            </p>
        </div>
    );
}
