import styles from "../styles.module.css";


export default function ReadingComprehension({reading}){
    return (
        <>
            <h3 className={styles.sectionTitle}>Reading Comprehension</h3>
            {reading.reading_comprehension.rows.map((comprehension, index) => (
                <section key={index} className={styles.comprehensionItem}>
                    <p className={styles.question}>{comprehension.question}</p>
                    {["option__1", "option__2", "option__3", "option__4"].map((optionKey) => (
                        <label key={optionKey} className={styles.labelQuestion}>
                            <input
                                type="radio"
                                name={`comprehension_${index}`}
                                value={comprehension[optionKey]}
                            />
                            <span>{comprehension[optionKey]}</span>
                        </label>
                    ))}
                </section>
            ))}
        </>
    )
}