import React, { useState } from "react";
import styles from "./styles.module.css";

export default function FillInTheBlankText({ lesson }) {
    const [answers, setAnswers] = useState({});

    const handleInputChange = (index, value) => {
        setAnswers((prevState) => ({
            ...prevState,
            [index]: value,
        }));
    };

    const renderTextWithInputs = () => {
        return lesson.exercise.test.fill_in_the_blank_text.rows.map((row, index) => {
            const parts = row.question.split(/(\(\d+\)\s*_{3,})/); // Разделяем текст по шаблону "(номер) ______________"
            return parts.map((part, i) =>
                part.match(/(\(\d+\)\s*_{3,})/) ? (
                    <input
                        key={`${index}-${i}`}
                        type="text"
                        className={styles.blankInput}
                        placeholder="______"
                        value={answers[index] || ""}
                        onChange={(e) => handleInputChange(index, e.target.value)}
                    />
                ) : (
                    <span key={`${index}-${i}`}>{part}</span>
                )
            );
        });
    };

    return (
        <div className={styles.fillInTheBlankTextContainer}>
            <h2 className={styles.sectionTitle}>G. Berilgen so’zlerden paydalanıp bos orınlardı toltırıń'</h2>
            <div className={styles.textContainer}>
                {renderTextWithInputs()}
            </div>
        </div>
    );
}
