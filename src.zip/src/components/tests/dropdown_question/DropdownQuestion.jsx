import styles from "./styles.module.css";


export default function DropdownQuestion({lesson}){

    return (
        <div className={styles.questions}>
            <h2 className={styles.sectionTitle}>A. Duris variantti tan'lan</h2>
            {lesson.exercise.test && lesson.exercise.test.dropdown_question.rows.map((test, index) => (
                <section key={index} className={styles.dropdown_question}>
                    <p className={styles.question}>
                        {test.question.split(/_{2,}/).flatMap((part, index, arr) => [
                            part,
                            index < arr.length - 1 && (
                                <select key={`select-${index}`} name="dropdown_question">
                                    <option value=""></option>
                                    <option value={test.option__1}>{test.option__1}</option>
                                    <option value={test.option__2}>{test.option__2}</option>
                                    <option value={test.option__3}>{test.option__3}</option>
                                </select>
                            ),
                        ])}
                    </p>

                </section>
            ))}
        </div>
    )
}