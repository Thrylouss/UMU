import React, { useState } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import styles from "./styles.module.css";

export default function ReorderSentences({ lesson }) {
    const [questions, setQuestions] = useState(
        lesson.exercise.test.reorder_sentences.rows.map((row) => ({
            ...row,
            shuffled: shuffleArray(row.reordered_sentence.split(" ")), // Перемешиваем слова
        }))
    );

    function shuffleArray(array) {
        return array.sort(() => Math.random() - 0.5);
    }

    const handleOnDragEnd = (result, index) => {
        if (!result.destination) return; // Если слово не перенесли в новое место, ничего не делаем

        const updatedQuestions = [...questions];
        const reorderedWords = Array.from(updatedQuestions[index].shuffled);
        const [movedWord] = reorderedWords.splice(result.source.index, 1);
        reorderedWords.splice(result.destination.index, 0, movedWord);

        updatedQuestions[index].shuffled = reorderedWords;
        setQuestions(updatedQuestions);
    };

    return (
        <div className={styles.reorderContainer}>
            <h2 className={styles.sectionTitle}>H. Сөзлерди орны орнна коюп га'плерди дурслан</h2>
            {questions.map((question, index) => (
                <div key={index} className={styles.questionBlock}>
                    {/*<p className={styles.correctSentence}>Sentence: {question.sentence}</p>*/}
                    <DragDropContext
                        onDragEnd={(result) => handleOnDragEnd(result, index)}
                    >
                        <Droppable droppableId={`droppable-${index}`} direction="horizontal">
                            {(provided) => (
                                <div
                                    className={styles.droppableArea}
                                    {...provided.droppableProps}
                                    ref={provided.innerRef}
                                >
                                    {question.shuffled.map((word, wordIndex) => (
                                        <Draggable
                                            key={`${index}-${wordIndex}`}
                                            draggableId={`${index}-${wordIndex}`}
                                            index={wordIndex}
                                        >
                                            {(provided) => (
                                                <span
                                                    className={styles.draggableWord}
                                                    ref={provided.innerRef}
                                                    {...provided.draggableProps}
                                                    {...provided.dragHandleProps}
                                                >
                                                    {word}
                                                </span>
                                            )}
                                        </Draggable>
                                    ))}
                                    {provided.placeholder}
                                </div>
                            )}
                        </Droppable>
                    </DragDropContext>
                </div>
            ))}
        </div>
    );
}
