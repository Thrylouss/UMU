import styles from "./styles.module.css";


export default function MultipleChoice({lesson}){
    return (
        <div className={styles.questions}>
            <h2 className={styles.sectionTitle}>B. Duris variantti tan'lan</h2>
            <div className={styles.questionContainer}>
                {lesson.exercise.test && (
                    <div className={styles.gridContainer}>
                        {lesson.exercise.test.multiple_choice.rows.map((test, index) => (
                            <section key={index} className={styles.multiple_choice}>
                                <p className={styles.question}>{test.question}</p>
                                <label className={styles.labelQuestion}>
                                    <input type="radio" name={`multiple_choice_${index}`} value={test.option__1} />
                                    <span>{test.option__1}</span>
                                </label>
                                <label className={styles.labelQuestion}>
                                    <input type="radio" name={`multiple_choice_${index}`} value={test.option__2} />
                                    <span>{test.option__2}</span>
                                </label>
                            </section>
                        ))}
                    </div>
                )}
            </div>

        </div>
    )
}