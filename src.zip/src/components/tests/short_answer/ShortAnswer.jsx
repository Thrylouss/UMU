import React, { useState } from "react";
import styles from "./styles.module.css";

export default function ShortAnswer({ lesson }) {
    const [answers, setAnswers] = useState({});

    const handleInputChange = (index, value) => {
        setAnswers((prevState) => ({
            ...prevState,
            [index]: value,
        }));
    };

    return (
        <div className={styles.shortAnswerContainer}>
            <h2 className={styles.sectionTitle}>
                F. Berilgen ga'lerden sorawlar jasap ha'm qisqa juwaplar jazıń
            </h2>
            <div className={styles.questions}>
                {lesson.exercise.test.short_answer.rows.map((row, index) => (
                    <div key={index} className={styles.questionRow}>
                        <p className={styles.sentence}>{row.sentence}</p>
                        <div className={styles.answerContainer}>
                            <input
                                type="text"
                                className={styles.questionInput}
                                placeholder="Question"
                            />
                            <input
                                type="text"
                                className={styles.answerInput}
                                placeholder="Your answer"
                                value={answers[index] || ""}
                                onChange={(e) => handleInputChange(index, e.target.value)}
                            />
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
