import React, { useState } from "react";
import styles from "./styles.module.css";

export default function FillInTheBlankD({ lesson }) {
    const [answers, setAnswers] = useState({});

    const handleInputChange = (index, value) => {
        setAnswers((prevState) => ({
            ...prevState,
            [index]: value,
        }));
    };

    return (
        <div className={styles.fillInTheBlankContainer}>
            <h2 className={styles.sectionTitle}>
                D. Berilgen so’zlerden paydalanıp bos orınlardı toltıruń':
            </h2>
            <div className={styles.wordBank}>
                {lesson.exercise.test.fill_in_the_blank_D.rows.map((test, index) => (
                    <span key={index}>{test.correct_answer}</span>
                ))}
            </div>
            <div className={styles.questions}>
                {lesson.exercise.test.fill_in_the_blank_D.rows.map((row, index) => (
                    <div key={index} className={styles.questionRow}>
                        <span className={styles.questionIndex}>{index + 1}.</span>
                        <input
                            type="text"
                            className={styles.blankInput}
                            placeholder="_____"
                            value={answers[index] || ""}
                            onChange={(e) => handleInputChange(index, e.target.value)}
                        />
                        <span>{row.question.replace("____", "")}</span>
                    </div>
                ))}
            </div>
        </div>
    );
}
