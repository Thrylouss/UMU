import {createBrowserRouter} from "react-router-dom";
import Levels from "../pages/levels/Levels.jsx";
import LoginPage from "../pages/auth/LoginPage.jsx";
import Lessons from "../components/lessons/Lessons.jsx";
import Tests from "../pages/tests/Tests.jsx";


export const router = createBrowserRouter(
    [
        {
            path: "/levels",
            element: <Levels/>
        },
        {
            path: "/login",
            element: <LoginPage/>
        },
        {
            path: "/levels/:ieltsLevel",
            element: <Lessons/>
        },
        {
            path: "/levels/:ieltsLevel/lessons/:lessonId",
            element: <Tests/>
        }
    ]
)