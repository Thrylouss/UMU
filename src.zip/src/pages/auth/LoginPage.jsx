import logo from '../../assets/logo/logo.png'
import {useRef} from "react";
import styles from './styles.module.css'

export default function LoginPage(){
    const login = useRef()
    const password = useRef()

    const handleSubmit = (e) => {
        e.preventDefault()
    }

    return (
        <div className={styles.wrapper}>
            <div className={styles.container}>
                <img className={styles.img} src={logo} alt=""/>
                <form className={styles.form} onSubmit={handleSubmit}>
                    <input ref={login} type="text" placeholder="Login"/>
                    <input ref={password} type="password" placeholder="Password"/>
                    <button type="submit">Login</button>
                </form>
            </div>
        </div>
    )
}