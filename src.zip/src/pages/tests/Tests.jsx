import styles from './styles.module.css'
import logo from '../../assets/logo/logo.png'
import {useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import axios from "axios";
import loadEffect from "../../assets/loadEffects/loadEffects.module.css"
import DropdownQuestion from "../../components/tests/dropdown_question/DropdownQuestion.jsx";
import MultipleChoice from "../../components/tests/multiple_choice/MultipleChoice.jsx";
import DropdownQuestionDialog from "../../components/tests/dropdown_question_dialog/DropdownQuestionDialog.jsx";
import FillInTheBlankD from "../../components/tests/fill_in_the_blank_D/FillInTheBlankD.jsx";
import FillInTheBlankE from "../../components/tests/fill_in_the_blank_E/FillInTheBlankE.jsx";
import ShortAnswer from "../../components/tests/short_answer/ShortAnswer.jsx";
import FillInTheBlankText from "../../components/tests/fill_in_the_blank_text/FillInTheBlankText.jsx";
import ReorderSentences from "../../components/tests/reorder_sentences/ReorderSentences.jsx";
import ReadingSection from "../../components/reading/ReadingSection.jsx";
import ListeningSection from "../../components/listening/ListeningSection.jsx";
import SpeakingSection from "../../components/speaking/SpeakingSection.jsx";

export default function Tests(){
    const { lessonId } = useParams()
    const [lesson, setLesson] = useState({});
    const [isLoading, setIsLoading] = useState(true); // Добавляем состояние загрузки
    const [error, setError] = useState(null); // Для обработки ошибок
    const [selectedOptions, setSelectedOptions] = useState({});

    const handleChange = (questionId, value) => {
        setSelectedOptions((prevState) => ({
            ...prevState,
            [questionId]: value, // Обновляем выбранный вариант для конкретного вопроса
        }));
    };

    useEffect(() => {
        setIsLoading(true); // Начало загрузки
        axios.get(`https://www.umumektebi.uz/api/lessons/${lessonId}`)
            .then((res) => {
                setLesson(res.data.lesson);
                setIsLoading(false); // Завершаем загрузку
            })
            .catch((err) => {
                console.error(err);
                setError("Failed to load the lesson data.");
                setIsLoading(false); // Завершаем загрузку даже в случае ошибки
            });
    }, [lessonId])

    if (!lesson || !lesson.exercise || !lesson.exercise.test) {
        console.log("Data is still loading or undefined.");
    } else {
        console.log(lesson.exercise.listening);
    }

    if (isLoading) return <div className={loadEffect.cont}>
        <div className={loadEffect.hourglass}></div>
    </div>;

    if (error) {
        return <div className={styles.container}>Error: {error}</div>; // Показать сообщение об ошибке
    }

    // Проверяем, есть ли данные lesson
    if (!lesson) {
        return <div className={styles.container}>No lesson data available.</div>;
    }

    return (
        <div className={styles.container}>
            <img className={styles.logo} src={logo} alt=""/>
            <div className={styles.testContainer}>
                <div className={styles.lessonDesc}>
                    <h1>{lesson.link.split('-l')[0]}</h1>
                    <div className={styles.lessonTitle}>
                        <h2>{lesson.description}</h2>

                    </div>
                    <h2 className={styles.description}>{lesson.title}</h2>
                </div>
                <iframe width="100%" height="100%" src="https://www.youtube.com/embed/bWf8eC9fLWw?si=aVcVad-HJ0FdtITR"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        referrerPolicy="strict-origin-when-cross-origin" allowFullScreen>
                </iframe>
                <h1>Tests</h1>
                <div className={styles.tests}>
                    <DropdownQuestion lesson={lesson}/>
                    <MultipleChoice lesson={lesson}/>
                    <DropdownQuestionDialog lesson={lesson}/>
                    <FillInTheBlankD lesson={lesson}/>
                    <FillInTheBlankE lesson={lesson}/>
                    <ShortAnswer lesson={lesson}/>
                    <FillInTheBlankText lesson={lesson}/>
                    <ReorderSentences lesson={lesson}/>
                </div>
                <h1>Reading</h1>
                <div className={styles.tests}>
                    <ReadingSection reading={lesson.exercise.reading}/>
                </div>
                <h1>Listening</h1>
                <div className={styles.tests}>
                    <ListeningSection listening={lesson.exercise.listening}/>
                </div>
                <h1>Speaking</h1>
                <div className={styles.tests}>
                    <SpeakingSection speakingData={lesson.exercise.speaking}/>
                </div>
            </div>
        </div>
    )
}